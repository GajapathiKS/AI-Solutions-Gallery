// src/core/orchestrator.ts
import fs from 'fs/promises';
import { PlannerAgent } from '../agents/plannerAgent.js';
import { ObserverAgent } from '../agents/observerAgent.js';
import { ExecutorAgent } from '../agents/executorAgent.js';

import { McpClient } from './mcpClient.js';
import { RunLogger } from './logger.js';
import { EnvironmentSettings } from './env.js';

export async function runAgenticTest(
  goalText: string,
  client: McpClient,
  env: EnvironmentSettings,
  logger: RunLogger,
  options: { runDir: string }
): Promise<void> {
  // Ensure artifacts directory exists
  await fs.mkdir(options.runDir, { recursive: true });

  // 1) Plan
  const planner = new PlannerAgent(logger);
  const plan = await planner.createPlan(goalText, {
    baseUrl: env.baseUrl,
    timeoutMs: env.timeoutMs,
  });

  // 2) Observer — IMPORTANT: pass env (EnvironmentSettings), not runDir
  const observer = new ObserverAgent(client, logger, env);

  // If your ObserverAgent supports configuring a runDir, try to set it
  if (typeof (observer as any).setRunDir === 'function') {
    (observer as any).setRunDir(options.runDir);
  } else if (typeof (observer as any).configure === 'function') {
    (observer as any).configure({ runDir: options.runDir });
  }

  // Optionally prime the observer with the base URL if it has observe(url)
  if (typeof (observer as any).observe === 'function') {
    await (observer as any).observe(env.baseUrl);
  }

  // 3) Executor — (client, logger, env, runDir)
  const executor = new ExecutorAgent(client, logger, env, options.runDir);

  // Execute plan (supports either execute(...) or run(...))
  const ex: any = executor;
  if (typeof ex.execute === 'function') {
    await ex.execute(plan, observer);
  } else if (typeof ex.run === 'function') {
    await ex.run(plan, observer);
  } else {
    logger.error('ExecutorAgent has neither execute(...) nor run(...)');
    throw new Error('ExecutorAgent API mismatch: no execute/run method');
  }
}
