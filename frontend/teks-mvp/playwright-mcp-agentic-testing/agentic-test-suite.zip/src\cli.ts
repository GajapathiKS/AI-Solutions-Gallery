// src/cli.ts
import fs from "fs";
import path from "path";
import { Command } from "commander";
import { fileURLToPath } from "url";

import { runAgenticTest } from "./core/orchestrator.js";
import { RunLogger } from "./core/logger.js";
import { McpClient } from "./core/mcpClient.js";
import { loadAgentConfig, selectEnvironment } from "./core/env.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function main() {
  const program = new Command();
  program
    .argument("<testFile>", "Path to the goal/test text file")
    .option("--env <name>", "Environment key (dev|qa|prod)")
    .option("--run-id <id>", "Run identifier for artifacts/logs");

  program.parse(process.argv);
  const [testFile] = program.args;
  const opts = program.opts<{ env?: string; runId?: string }>();

  if (!testFile) {
    console.error("Missing <testFile> argument");
    process.exit(1);
  }

  const configPath = path.resolve(__dirname, "../agent.config.json");
  const config = loadAgentConfig(configPath);
  const envSel = selectEnvironment(config, opts.env);
  const runId = opts.runId || new Date().toISOString().replace(/[:.]/g, "-");

  const artifactsRoot = path.resolve(__dirname, "..", config.artifactsDir || "reports");
  const runDir = path.join(artifactsRoot, runId);
  fs.mkdirSync(runDir, { recursive: true });

  const logger = new RunLogger(runId, runDir);
  logger.info("Run started", { runId, startedAt: new Date().toISOString() });
  logger.info("Loaded test goal", { file: path.resolve(testFile) });

  const goalText = fs.readFileSync(path.resolve(testFile), "utf-8");

  // MCP
  const mcpClient = new McpClient(logger);
  [{
	"resource": "/c:/MCP_POCS/AIProjects/frontend/teks-mvp/playwright-mcp-agentic-testing/src/cli.ts",
	"owner": "typescript",
	"code": "2345",
	"severity": 8,
	"message": "Argument of type 'McpConfig' is not assignable to parameter of type 'McpLaunchConfig'.\n  Type 'McpConfig' is not assignable to type '{ mode: \"stdio\"; stdioCommand: [string, ...string[]]; cwd?: string | undefined; env?: Record<string, string> | undefined; }'.\n    Types of property 'stdioCommand' are incompatible.\n      Type 'string[]' is not assignable to type '[string, ...string[]]'.\n        Source provides no match for required element at position 0 in target.",
	"source": "ts",
	"startLineNumber": 48,
	"startColumn": 27,
	"endLineNumber": 48,
	"endColumn": 37,
	"origin": "extHost1"
},{
	"resource": "/c:/MCP_POCS/AIProjects/frontend/teks-mvp/playwright-mcp-agentic-testing/src/core/orchestrator.ts",
	"owner": "typescript",
	"code": "2345",
	"severity": 8,
	"message": "Argument of type 'string' is not assignable to parameter of type 'EnvironmentSettings'.",
	"source": "ts",
	"startLineNumber": 29,
	"startColumn": 54,
	"endLineNumber": 29,
	"endColumn": 65,
	"origin": "extHost1"
},{
	"resource": "/c:/MCP_POCS/AIProjects/frontend/teks-mvp/playwright-mcp-agentic-testing/src/core/orchestrator.ts",
	"owner": "typescript",
	"code": "2554",
	"severity": 8,
	"message": "Expected 1 arguments, but got 0.",
	"source": "ts",
	"startLineNumber": 34,
	"startColumn": 18,
	"endLineNumber": 34,
	"endColumn": 25,
	"relatedInformation": [
		{
			"startLineNumber": 35,
			"startColumn": 17,
			"endLineNumber": 35,
			"endColumn": 28,
			"message": "An argument for 'url' was not provided.",
			"resource": "/c:/MCP_POCS/AIProjects/frontend/teks-mvp/playwright-mcp-agentic-testing/src/agents/observerAgent.ts"
		}
	],
	"origin": "extHost1"
}]

  try {
    await runAgenticTest(
      goalText,
      mcpClient,
      envSel.settings,
      logger,
      { runDir }
    );
    logger.info("Run finished", { runId, artifactsDir: runDir });
    console.log(`Artifacts: ${runDir}`);
    process.exitCode = 0;
  } catch (err: any) {
    logger.error("Run failed", { error: err?.message || String(err) });
    process.exitCode = 1;
  } finally {
    await mcpClient.close().catch(() => {});
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
