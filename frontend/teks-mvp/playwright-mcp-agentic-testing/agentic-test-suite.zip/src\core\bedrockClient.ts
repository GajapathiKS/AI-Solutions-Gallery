// src/core/bedrockClient.ts
/**
 * Minimal Bedrock (Nova Lite) JSON helper using Bearer token.
 * Env:
 *  - AWS_REGION
 *  - BEDROCK_MODEL_ID (e.g. "amazon.nova-lite-v1:0")
 *  - AWS_BEARER_TOKEN_BEDROCK
 */
export interface BedrockClientOptions {
  region?: string;
  modelId?: string;
  bearerToken?: string;
}

export class BedrockClient {
  private readonly region: string;
  private readonly modelId: string;
  private readonly token: string;

  constructor(opts: BedrockClientOptions = {}) {
    this.region = opts.region || process.env.AWS_REGION || "us-east-1";
    this.modelId = opts.modelId || process.env.BEDROCK_MODEL_ID || "amazon.nova-lite-v1:0";
    this.token = opts.bearerToken || process.env.AWS_BEARER_TOKEN_BEDROCK || "";
    if (!this.token) {
      throw new Error("AWS_BEARER_TOKEN_BEDROCK is required");
    }
  }

  /** Ask model to return JSON (we validate outside with zod if needed). */
  async generateJSON<T>(systemPrompt: string, userPrompt: string): Promise<T> {
    const url = `https://bedrock-runtime.${this.region}.amazonaws.com/model/${encodeURIComponent(this.modelId)}/invoke`;
    const body = {
      inputText: `${systemPrompt}\n\nUSER:\n${userPrompt}\n\nReturn ONLY strict JSON.`,
      textGenerationConfig: {
        temperature: 0.2,
        topP: 0.9,
        maxTokenCount: 2000,
      },
    };

    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${this.token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const t = await res.text();
      throw new Error(`Bedrock error ${res.status}: ${t}`);
    }

    const payload = await res.json() as any;
    // Nova-lite returns { output:{ text:string } } in text mode; we asked for JSON string.
    const raw = payload?.output?.text ?? payload?.generated_text ?? "";
    try {
      return JSON.parse(raw) as T;
    } catch {
      // Attempt to extract JSON block
      const m = String(raw).match(/\{[\s\S]*\}$/);
      if (!m) throw new Error("Bedrock returned non-JSON content");
      return JSON.parse(m[0]) as T;
    }
  }
}
