// src/agents/plannerAgent.ts
import { z } from "zod";
import { RunLogger } from "../core/logger.js";
import { BedrockClient } from "../core/bedrockClient.js";
import type { AgentPlan } from "../core/schema.js";

const PlanSchema = z.object({
  steps: z.array(z.object({
    type: z.enum([
      "navigate","type","click","press","selectOption","hover","drag","waitFor","screenshot","resize"
    ]),
    target: z.string().optional(),
    value: z.string().optional(),
    timeoutMs: z.number().optional()
  })),
  verification: z.array(z.object({
    type: z.enum(["text","visible","url","exists"]),
    target: z.string().optional(),
    value: z.string().optional(),
    timeoutMs: z.number().optional()
  })).default([])
});

export class PlannerAgent {
  constructor(
    private readonly logger: RunLogger,
    private readonly bedrock = new BedrockClient()
  ) {}

  async createPlan(goalText: string, ctx: { baseUrl: string; timeoutMs: number }): Promise<AgentPlan> {
    const system = `You are an E2E test planner for a Playwright+MCP agent.
Return JSON with { steps: Step[], verification: VerifyStep[] }.
- "navigate" value must be a full URL.
- "type" requires { target, value } where target is a CSS selector or label text.
- prefer robust selectors like input[name="username"], button[type="submit"].
- verification must include at least one step, e.g. {type:"visible",target:"#students-tab"} or {type:"text",target:"body",value:"Students"}.`;

    const user = `Goal:\n${goalText}\n\nBase URL: ${ctx.baseUrl}\nDefault timeout: ${ctx.timeoutMs}ms\n`;

    const raw = await this.bedrock.generateJSON<any>(system, user);
    const parsed = PlanSchema.safeParse(raw);
    if (!parsed.success) {
      this.logger.warn("Planner JSON parse failed, building fallback plan", { issues: parsed.error.issues as any });
      // conservative fallback: just navigate to possible login & leave verification visible Students tab
      const fallback: AgentPlan = {
        steps: [
          { type: "navigate", value: `${ctx.baseUrl}/login` },
        ],
        verification: [
          { type: "visible", target: "#students-tab", timeoutMs: ctx.timeoutMs }
        ],
      };
      return fallback;
    }

    const plan = parsed.data as AgentPlan;
    if (!plan.verification?.length) {
      plan.verification = [{ type: "visible", target: "#students-tab", timeoutMs: ctx.timeoutMs }];
    }
    return plan;
  }
}
