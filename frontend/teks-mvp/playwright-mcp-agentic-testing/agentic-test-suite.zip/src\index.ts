#!/usr/bin/env node
import './cli.js';
