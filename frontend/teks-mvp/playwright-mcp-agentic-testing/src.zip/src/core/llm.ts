export function sanitizeJs(fromLlm: string) {
  let s = fromLlm.trim();
  // strip ```javascript ... ``` or ``` ... ```
  if (s.startsWith("```")) {
    s = s.replace(/^```[a-zA-Z]*\n?/, "").replace(/```$/, "");
  }
  return s.trim();
}

export const SYSTEM_RULES = [
  "Return ONLY JavaScript. No markdown, no backticks.",
  "⚠️ Never create elements (no document.createElement / appendChild). Interact with EXISTING controls only.",
  "Do NOT use :contains() or setTimeout.",
  "Use let (not const) when a variable may be reassigned.",
  "After setting input/textarea/select values, dispatch BOTH 'input' and 'change' events with { bubbles: true } (Angular Reactive Forms).",
  "Prefer querySelector with stable attributes: [formcontrolname], [name], [id], [placeholder].",
  "If a control isn't found, search by label text via Array.from and match normalized innerText.",
].join("\n");
