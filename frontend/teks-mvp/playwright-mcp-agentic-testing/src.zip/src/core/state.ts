// src/core/state.ts
import { mcpClient } from "./mcpClient.js";

export type DomSnapshot = {
  route: string;
  title: string;
  forms: Array<{
    name?: string;
    actionBtnTexts: string[];
    inputs: Array<{ name?: string; id?: string; formControlName?: string; type?: string; labelText?: string }>;
  }>;
  buttons: Array<{ text: string; type?: string; id?: string }>;
};

const stack: string[] = [];
let memory: Record<string, any> = {}; // last used selectors, IDs, new entity IDs, etc.

export async function getDomSnapshot(): Promise<DomSnapshot> {
  const route = (await mcpClient.call("page_url", {})) as string;
  const title = (await mcpClient.call("page_title", {})) as string;

  // extract forms/inputs/buttons inside page context
  const dom: DomSnapshot = await mcpClient.call("browser_evaluate", {
    expression: `
(() => {
  const q = (sel) => Array.from(document.querySelectorAll(sel));
  const text = (el) => el?.innerText?.trim() || el?.textContent?.trim() || "";
  const inputs = q('input, textarea, select').map(el => ({
    name: el.name || undefined,
    id: el.id || undefined,
    formControlName: el.getAttribute('formcontrolname') || undefined,
    type: el.type || el.tagName.toLowerCase(),
    labelText: el.id ? (document.querySelector('label[for="'+el.id+'"]')?.innerText?.trim() || undefined) : undefined
  }));
  const buttons = q('button').map(b => ({ text: (b.getAttribute('aria-label') || b.innerText || '').trim(), type: b.type || undefined, id: b.id || undefined }));
  const forms = q('form').map(f => ({
    name: f.getAttribute('name') || undefined,
    actionBtnTexts: q('button', f).map(b => (b.innerText || '').trim()).filter(Boolean),
    inputs: q('input, textarea, select', f).map(el => ({
      name: el.name || undefined,
      id: el.id || undefined,
      formControlName: el.getAttribute('formcontrolname') || undefined,
      type: el.type || el.tagName.toLowerCase(),
      labelText: el.id ? (document.querySelector('label[for="'+el.id+'"]')?.innerText?.trim() || undefined) : undefined
    }))
  }));
  return { route: location.href, title: document.title, forms, buttons };
})()`
  }) as DomSnapshot;

  // URL stack
  if (!stack.length || stack[stack.length - 1] !== route) stack.push(route);
  return dom;
}

export function remember(k: string, v: any) { memory[k] = v; }
export function recall<T = any>(k: string): T | undefined { return memory[k] as T; }
export function navTrail() { return [...stack]; }
