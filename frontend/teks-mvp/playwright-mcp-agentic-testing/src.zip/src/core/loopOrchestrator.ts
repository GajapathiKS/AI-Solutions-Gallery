// src/core/loopOrchestrator.ts
import { getDomSnapshot } from "./state.js";
import { bedrockConverse } from "./bedrockClient.js";
import { mcpClient } from "./mcpClient.js";
import { logger } from "./logger.js";

type LoopInput = {
  goal: string;              // plain English objective
  maxSteps?: number;         // safety
  url?: string;              // optional starting route
};

type LoopResult = {
  status: "done" | "incomplete";
  steps: number;
  reason?: string;
};

export async function runAgentLoop({ goal, maxSteps = 12, url }: LoopInput): Promise<LoopResult> {
  if (url) await mcpClient.call("page_goto", { url });

  for (let step = 1; step <= maxSteps; step++) {
    const dom = await getDomSnapshot(); // forms, inputs, buttons, route, title, visible text
    const obs = {
      url: await mcpClient.call("page_url", {}),
      title: await mcpClient.call("page_title", {}),
      ready: await mcpClient.call("page_content", { of: "visibility" }),
      dom,
      step
    };

    logger.info({ t: "observe", step, obs });

    // System prompt mirrors your DOM-Intelligent guidance (no :contains, no setTimeout, dispatch events)
    const sys = [
      "You are a DOM-Intelligent testing agent.",
      "Generate minimal JavaScript to achieve the next sub-goal.",
      "Rules: Do not use :contains() or setTimeout. Use let for reassignable vars.",
      "When setting values, also dispatch input/change events (bubbles: true) for Angular.",
      "Return ONLY JavaScript; no prose."
    ].join("\n");

    const user = [
      `High-level goal: ${goal}`,
      "Current page metadata:",
      JSON.stringify({ url: obs.url, title: obs.title }),
      "DOM snapshot (truncated keys):",
      JSON.stringify(dom, null, 2),
      "Given the goal, produce the NEXT SMALL step only."
    ].join("\n\n");

    const js = await bedrockConverse(sys, user); // Nova Lite as you already use:contentReference[oaicite:2]{index=2}

    logger.info({ t: "plan", step, js });

    // Execute inside the page
    const exec = await mcpClient.call("browser_evaluate", { expression: js }); // your proven path:contentReference[oaicite:3]{index=3}
    logger.info({ t: "act", step, exec });

    // Quick success probe after each step (URL change, toast, row appears, etc.)
    const probe = await quickProbe(goal);
    logger.info({ t: "probe", step, probe });

    if (probe.done) {
      logger.info({ t: "done", step, reason: probe.reason });
      return { status: "done", steps: step, reason: probe.reason };
    }
  }

  return { status: "incomplete", steps: maxSteps, reason: "Max steps reached without satisfying goal" };
}

type ProbeResult = {
  done: boolean;
  reason?: string;
};

async function quickProbe(goal: string): Promise<ProbeResult> {
  // Example probes; swap with your domain cues
  const url = await mcpClient.call("page_url", {});
  const html = await mcpClient.call("page_content", { of: "body" });

  if (/success|added|created/i.test(html as string)) return { done: true, reason: "Success text found" };
  if (/students($|\/\d+)/.test(url as string) && /table/i.test(html as string)) return { done: true, reason: "List page with table reached" };
  return { done: false, reason: "Goal not satisfied yet" };
}
